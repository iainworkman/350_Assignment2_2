<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <a href="MySQL/connectToMySQL.php">
		<img src="resources/MySQL logo.jpg" alt="MySQL Version"  />
		</a>
		<a href="MySQL/connectToAzure.php">
		<img src="resources/azure logo.png" alt="MySQL Version" " />
		</a>
    </body>
</html>
